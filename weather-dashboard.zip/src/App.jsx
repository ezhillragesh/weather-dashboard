import Weather from './components/dashboard';

import './App.css'

function App(){
  return(<>
    <Weather />
  </>);
}

export default App
